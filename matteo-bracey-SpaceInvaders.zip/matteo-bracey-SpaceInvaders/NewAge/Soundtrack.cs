﻿using System;
using System.Media;
// (added reference Presentation Core.dll. to use MediaPlayer)
using System.Windows.Media;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Make two different sound, the main music and a noise when a missile is launched

namespace NewAge
{
    class Soundtrack
    {

        // Main soundtrack player
        private SoundPlayer _mainSoundtrack;

        // Relative path of the main sound track in the project file
        private string _pathMainSoundtrack;

        // Missile soundtrack player (gunshot noise)
        private MediaPlayer _missileSoundtrack;

        // Relative path of the missile soundtrack in the project file
        private Uri _pathMissileSoundtrack;

        /// <summary>
        /// Variable are intialized, the main soundtrack is launched
        /// </summary>
        public Soundtrack()
        {
            // Relative path of the main soundtrack
            _pathMainSoundtrack = @"../../music-SpaceInvaders/SW-AvsO.wav";

            // Create the SoundPlayer for the main soundtrack
            _mainSoundtrack = new SoundPlayer(_pathMainSoundtrack);

            // Create the Uri path for the missileSoundtrack, with the relative path
            _pathMissileSoundtrack = new Uri("../../music-SpaceInvaders/gunshot.wav", UriKind.Relative);

            // Create the MediaPlayer for the main soundtrack
            _missileSoundtrack = new MediaPlayer();

            // MediaPlayer needs to open the track before playing it
            _missileSoundtrack.Open(_pathMissileSoundtrack);

            // The main soundtrack is played
            MainSoundtrack();
        }

        /// <summary>
        /// Play the main soundtrack continuely who last appromaxitely 3 minutes
        /// </summary>
        private void MainSoundtrack()
        {
            // The main sound track is played continuesouly
            _mainSoundtrack.PlayLooping();
        }

        /// <summary>
        /// Play the missile soundtrack who it is a gunshot noise that last 1 second when the spaceship shot a missile
        /// </summary>
        public void SoundMissile()
        {
            // Music need to be reopen to be played multiple times
            _missileSoundtrack.Open(_pathMissileSoundtrack);

            // The gunshot noise is played
            _missileSoundtrack.Play();
        }
    }
}
