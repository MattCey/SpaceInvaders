﻿using System.Collections.Generic;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Create and move the alien shots in the main game matrice, checks if a shot has hit a wall, the spaceship, the bottom border
// Verify if an alien shoot has had a collision with one of the missile, decrease life when shot hit spaceship

namespace NewAge
{
    class Shoots
    {
        // list of the x horizontal index of  Aliens shots
        private List<int> _listXPositionShoot;

        // list of the y vertical index of Aliens shots
        private List<int> _listYPositionShoot;

        // ASSCI charachter of the Alien Shoot
        public char SHOOT_SYMBOLE = '8';
        private char _charShoot;

        // Index of the walls in the main game matrice
        private BoardWall _boardWall;

        // Index of the aliens
        private BoardAlien _boardAlien;

        // Index of the Spaceship
        private SpaceShip _spaceShip;

        // Main game matrice
        private GameMatrice _gameMatrice;

        // ASSCI charachters of the wall
        private Wall _wall = new Wall();

        // Control if alien shots hit a missile
        private Missile _missile;

        // Decrease life of player when missile hit spaceship
        private ScoreInfo _scoreInfo;

        public Shoots()
        {

        }

        /// <summary>
        /// Initalise value of alien shoot
        /// </summary>
        /// <param name="boardWall">wall position and character</param>
        /// <param name="boardAlien">Alien position and character</param>
        /// <param name="spaceShip">space ship position</param>
        /// <param name="gameMatriceA">main game matrice</param>
        /// <param name="missileA">missile charachter</param>
        /// <param name="scoreInfoA">Change life in score area</param>
        public Shoots(BoardWall boardWall, BoardAlien boardAlien, SpaceShip spaceShip, GameMatrice gameMatriceA, Missile missileA, ScoreInfo scoreInfoA)
        {
            // Intialise different variable
            _listXPositionShoot = new List<int>();
            _listYPositionShoot = new List<int>();
            _gameMatrice = gameMatriceA;
            _charShoot = SHOOT_SYMBOLE;
            _boardWall = boardWall;
            _boardAlien = boardAlien;
            _spaceShip = spaceShip;
            _missile = missileA;
            _scoreInfo = scoreInfoA;
        }

        /// <summary>
        ///Define the alien shot index in the game matrice, each shot have index vertical and horizontal who are stored in two lists and will change position over time
        /// </summary>
        public void NewShoot()
        {
            //Random Selected Alien
            _boardAlien.ShootingAlienPosition();

            // Create a shoot with the horizontal and vertical position of the bottom of the alien
            _listXPositionShoot.Add(_boardAlien.AlienXshootPosition());
            _listYPositionShoot.Add(_boardAlien.AlienYshootPosition());
        }

        /// <summary>
        ///  Change the vertical position of the alien shoot as they go down, check if they hit the spaceship , a brick of a wall or the bottom border or a missile
        /// </summary>
        public void WriteShootMove()
        {
            // Change each missile vertical index in the list
            for (int i = 0; i < _listXPositionShoot.Count; i++)
            {
                //Write the position in the main gain matrice
                _gameMatrice.GameMatrix[_listYPositionShoot[i], _listXPositionShoot[i]] = _charShoot;

                // Shoot Change Position
                _listYPositionShoot[i] += 1;

                //WALL
                //Shoot is in Wall Vertical Zone
                if (_listYPositionShoot[i] >= _boardWall.IndexWallY && _listYPositionShoot[i] < _boardWall.IndexWallY + _wall.ArrWallChar.GetLength(0))
                {
                    //The missile is on a Wall that is still in life define by the two wall bricks character
                    if (_gameMatrice.GameMatrix[_listYPositionShoot[i], _listXPositionShoot[i]] == _wall.WallOne
                        || _gameMatrice.GameMatrix[_listYPositionShoot[i], _listXPositionShoot[i]] == _wall.WallTwo)
                    {
                        //If the missile has impacted a Wall 
                        if (_boardWall.WallImpact(missileXCoord: _listXPositionShoot[i], missileYCoord: _listYPositionShoot[i]))
                        {
                            //We remove the shoot it has hit a wall
                            RemoveShoot(i);

                            // We go to the next shoot
                            break;
                        }

                    }
                }
                // Shoot hit the bottom of the matrice
                if (_listYPositionShoot[i] == _gameMatrice.GameMatrix.GetLength(0))
                {
                    // We remove the shoot it has hit the bottom
                    RemoveShoot(listIndex: i);

                    // We go to the next shoot
                    break;
                }

                //if Missile hit an Alien Shoots
                if (_gameMatrice.GameMatrix[_listYPositionShoot[i], _listXPositionShoot[i]] == '$')
                {
                    // Verifiy index, remove alien shot and missile
                    if (_missile.MissileShootImpact(_listXPositionShoot[i], _listYPositionShoot[i]))
                    {
                        // We remove the shoot it has hit a missile
                        RemoveShoot(listIndex: i);

                        // We go to the next shoot
                        break;
                    }

                }

                // Shoot is in the spaceship horizontal area
                if (_listYPositionShoot[i] >= _spaceShip.IndexYSpaceShip && _listYPositionShoot[i] < _gameMatrice.GameMatrix.GetLength(0))
                {
                    // Shoot hit the spaceship
                    if (_gameMatrice.GameMatrix[_listYPositionShoot[i], _listXPositionShoot[i]] != '\0')
                    {
                        // Reduce life of the spaceShip
                        _scoreInfo.ReduceLife();

                        // We remove the shoot it has hit the spaceship
                        RemoveShoot(listIndex: i);

                        // We go to the next shoot
                        break;
                    }
                }
            }
        }

        /// <summary>
        /// Alien shot hit something and is removed form the list
        /// </summary>
        /// <param name="listIndex">index of the alien shot same in the horizontal and vertical list</param>
        private void RemoveShoot(int listIndex)
        {
            // Remove Missile from the two list
            _listXPositionShoot.RemoveAt(listIndex);
            _listYPositionShoot.RemoveAt(listIndex);
        }


    }
}
