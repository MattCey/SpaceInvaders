﻿using System.Collections.Generic;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: The Wall are made of ASSCI charachter, each character represent a brick and each of them have a life who decreas when they are hit by the spaceship missile
// or Alien shoot

namespace NewAge
{
    class Wall
    {
        // Dimension of the Wall
        public int WallHeight{ get; }
        public int WallWidth  { get; }

        // Type of wall ASCII Character
        private const char WALL_ONE = '▓';

        private const char WALL_TWO = '▒';

        public char WallOne { get; }
        public char WallTwo { get; }

        // Life of each brick a wall
        private const int NB_OF_LIFE_WALL = 2;

        // Array of the wall characters
        public char[,] ArrWallChar { get; }

        // life matrice of the wall
        private int[,] _arrWallLife;

        // index verical always the same for the four walls
        public int IndexWallY { get; set; }

        // index horizontal of the four  walls
        public int IndexWallX { get; set; }
        
        // The wall will be written in the matrice
        private GameMatrice gameMatrice;


        /// <summary>
        /// Dimension and the different charachters of the wall, made for composition
        /// </summary>
        public Wall()
        {
            // Wall dimension
            WallWidth = 12;
            WallHeight = 2;

            // Wall charachter different represent a brick in the wall, change when life of the brick decrease
            WallOne = WALL_ONE;
            WallTwo = WALL_TWO;

            // according to dimensions of the wall
            ArrWallChar = new char[WallHeight, WallWidth];

        }

        /// <summary>
        /// Set the dimension, the char and
        /// </summary>
        /// <param name="gameMatriceA"> main gamematrice, it will set the wall in this matrice</param>
        public Wall(GameMatrice gameMatriceA)
        {
            // Main matrice 
            gameMatrice = gameMatriceA;

            // type of wall different ASCII charachter
            WallOne = WALL_ONE;
            WallTwo = WALL_TWO;

            // Wall dimension
            WallWidth = 12;
            WallHeight = 2;

            // according to dimensions of the wall
            ArrWallChar = new char[WallHeight, WallWidth];

            // according to number of wall and dimension
            _arrWallLife = new int[WallHeight, WallWidth];
            
            // Assign the life value for each brick
            SetWallLife();
        }

        /// <summary>
        /// Assign the life value in the wall life array, each brick have a life represented by an integer
        /// </summary>
        private void SetWallLife()
        {
            for (int i = 0; i < ArrWallChar.GetLength(0); i++)
            {
                for (int j = 0; j < ArrWallChar.GetLength(1); j++)
                {
                    // Set the cell with a life
                    _arrWallLife[i, j] = NB_OF_LIFE_WALL;
                }
            }
        }

        /// <summary>
        /// Write the wall charachters in the main matrice, the character depends on the life of the brick
        /// </summary>
        public void WriteBricks()
        {
            for (int i = 0; i < ArrWallChar.GetLength(0); i++)
            {
                for (int j = 0; j < ArrWallChar.GetLength(1); j++)
                {
                    // Set right brick character according to his life
                    gameMatrice.GameMatrix[IndexWallY + i, IndexWallX + j] = LifeBricks(i, j);
                }
            }
        }

        /// <summary>
        /// Return the right brick ASSCI charachter according to the life of the brick
        /// </summary>
        /// <param name="i">vertical index</param>
        /// <param name="j">horizontal index</param>
        /// <returns></returns>
        private char LifeBricks(int i, int j)
        {
            // Brick is dead
            if (_arrWallLife[i, j] == 0)
            {
                return ' ';
            }
            // Brick is new
            else if (_arrWallLife[i, j] == 2)
            {
                return WALL_ONE;
            }
            // Brick is damaged
            else
            {
                return WALL_TWO;
            }
        }

        /// <summary>
        /// Check if the missile is in the current wall it will reduce the life of the brick if it has still life
        /// </summary>
        /// <param name="indexXMissile"> position of the missile in the main matrice</param>
        /// <param name="indexYMissile">position of the missile in the main matrice</param>
        /// <returns>true if the missile has hit a wall</returns>
        public bool CheckAllBricks(int indexXMissile, int indexYMissile)
        {
            for (int i = 0; i < ArrWallChar.GetLength(0); i++)
            {
                for (int j = 0; j < ArrWallChar.GetLength(1); j++)
                {
                    // the missile is in the same position as one of the brick of the wall
                    if (indexXMissile == IndexWallX + j && indexYMissile == IndexWallY + i)
                    {
                        // decrease life brick at index
                        ReduceBrickLife(brickXIndex: j, brickYIndex: i);
                        // a brick has been hit
                        return true;
                    }
                }
            }
            // no brick have been damaged
            return false;
        }

        /// <summary>
        /// Reduce the life of a brick of the Wall, if it is stril in life
        /// </summary>
        /// <param name="brickXIndex">vertical index</param>
        /// <param name="brickYIndex">horizontal index</param>
        private void ReduceBrickLife(int brickXIndex, int brickYIndex)
        {
            // life of the brick superior to 0
            if (_arrWallLife[brickYIndex, brickXIndex] > 0)
            {
                // Reduce Life of the Brick
                _arrWallLife[brickYIndex, brickXIndex]--;
            }
        }
    }
}

