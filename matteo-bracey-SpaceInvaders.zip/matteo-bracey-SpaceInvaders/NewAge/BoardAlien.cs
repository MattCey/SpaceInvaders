﻿using System.Collections.Generic;
using System;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Controls a 2d array of Aliens to control their movement and if a missile hit him. Their are multiple variable who define where Aliens start moving, when they stop, etc.
// The movement are based on the index of the first Alien of the array (top left corner)

namespace NewAge
{

    class BoardAlien
    {
        // in the board the three row of the top will get the first type of Alien, the fourth the second type and fifth the third type
        // number of row of alien
        private int _nbRowAlien;

        // number of column Alien
        private int _nbColAlien;

        // The first row of alien will be set 10 distance from the top of the Console
        public int _firstAlienDistanceTop { get; private set; }

        // The ScoreInfo
        private ScoreInfo _scoreInfo;

        // Matrice of Alien
        private Alien[,] _boardAlien;

        // Get size console
        private GameMatrice _gameMatrice;

        // Wall distance
        private BoardWall _wall;

        // Index of the first charachter of the first Alien
        private int _firstXAlienDistance;

        // Width size of the last Alien
        private int _indexHorizontalLastAlien;

        // Height size of the last Alien
        private int _indexVerticalLastAlien;

        // Movement direction false alien move to left and true alien mvoe to right
        private bool _aliensMovingRight;

        // Has mooved down, false if the alien hasn't moved down and true if the alien has moved down
        private bool _aliensMovedDown;

        // Maximum distance alien can get to the bottom of the console
        public int LimitDistanceAliensFromBottom { get; }

        // List of the Alien still alive 
        private List<Alien> lstAlienInLife;

        // random Alien index
        private int _rndIndexAlien;

        // counter used for the movement of the Aliens
        private int _counter;

        // vertical distance between the feet of the Alien and the head of the Alien of the row beneath
        private int _verticalDistanceBetweenAliens;

        // horizontal distance between the sides of the Aliens
        private int _horizontalDistanceBetweenAliens;

        public BoardAlien()
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="gameMatriceA">main game matrice</param>
        /// <param name="boardWallA">wall matrice</param>
        /// <param name="scoreInfoA">Increase the score when alien got shot</param>
        public BoardAlien(GameMatrice gameMatriceA , BoardWall boardWallA, ScoreInfo scoreInfoA)
        {
    
            // Alien didnt moved at the beginning
            _aliensMovedDown = false;

            _gameMatrice = gameMatriceA;
            _wall = boardWallA;

            
            _nbRowAlien = 5;
            _nbColAlien = 11;

            // The first row of alien will be set 10 distance from the top of the Console
            _firstAlienDistanceTop = 10;

            _verticalDistanceBetweenAliens = 2;
            _horizontalDistanceBetweenAliens = 5;

            // alien matrice
            _boardAlien = new Alien[_nbRowAlien, _nbColAlien];

            // First Alien index
            _firstXAlienDistance = _gameMatrice.GameMatrix.GetLength(0) / (_nbColAlien + 1);
           

            //The Alien move first to the left
            _aliensMovingRight = false;


            // Maximum distance alien can get to the bottom of the console
            LimitDistanceAliensFromBottom = _wall.IndexWallY - 5;

            // List of the Alien still alive 
            lstAlienInLife = new List<Alien>();
            //
            _scoreInfo = scoreInfoA;

            //Set the array of Alien with their type
            SetBoardAlien();

            // Write the Aliens in the main game matrice
            WriteAliens();
        }

        /// <summary>
        /// Set alien and define their types in the board
        /// </summary>
        private void SetBoardAlien()
        {
            // Initialise the board of alien
            for (int i = 0; i < _boardAlien.GetLength(0); i++)
            {
                for (int j = 0; j < _boardAlien.GetLength(1); j++)
                {
                    // three first line, first type
                    if (i < 3)
                    {
                        _boardAlien[i, j] = new Alien(alienTypeIndex: 0, gameMatriceA: _gameMatrice);
                    }
                    // fourth line, second type
                    else if (i == 3)
                    {
                        _boardAlien[i, j] = new Alien(alienTypeIndex: 2, gameMatriceA: _gameMatrice);
                    }
                    // fifth and last line, third type
                    else
                    {
                        _boardAlien[i, j] = new Alien(alienTypeIndex: 4,gameMatriceA: _gameMatrice);
                    }
                }
            }
        }

        /// <summary>
        /// Write the Aliens in the main game matrice, go threw the 2d array of Alien and write each of them and change the value of their index, when they move
        /// based on the horizontal and vertical index of the first Alien
        /// </summary>
        public void WriteAliens()
        {
            //Horizontal index of the aliens from the top border
            int xAlien = _firstXAlienDistance;

            // Vertical index of the aliens from the left border
            int yAlien = _firstAlienDistanceTop;

            // Write aliens line by line
            for (int i = 0; i < _boardAlien.GetLength(0); i++)
            {
                // After the first line increase the vertical index of the Aliens for next row
                if(i>0)
                {
                    // Add to the vertical index the height of the previous line alien and the vertical distance
                    yAlien += _boardAlien[i - 1, 0]._lstAlienType[_boardAlien[i - 1, 0].indexAlienType].GetLength(0) + _verticalDistanceBetweenAliens;
                }

                // Write aliens of a line
                for (int j = 0; j < _boardAlien.GetLength(1); j++)
                {
                    // After the first column Alien
                    if (j > 0)
                    {
                        // Add to the horizontal index the width of the previous alien and the horizontal distance
                        xAlien += _horizontalDistanceBetweenAliens + _boardAlien[i, j]._lstAlienType[_boardAlien[i, j].indexAlienType].GetLength(1);
                    }
                    // Last iteration of the two loops store the last alien horizontal and vertical index, they will be used for the movements
                    if (j == _boardAlien.GetLength(1) - 1 && i == _boardAlien.GetLength(0) - 1)
                    {
                        _indexHorizontalLastAlien = xAlien +_boardAlien[i, j]._lstAlienType[_boardAlien[i, j].indexAlienType].GetLength(1);
                        _indexVerticalLastAlien = yAlien +_boardAlien[i, j]._lstAlienType[_boardAlien[i, j].indexAlienType].GetLength(0);                       
                    }

                    // Set the vertical and horizontal index of the aliens
                    _boardAlien[i, j].IndexXAlien = xAlien;
                    _boardAlien[i, j].IndexYAlien = yAlien;

                    // Write the alien in the main matrice
                    _boardAlien[i, j].WriteAlien(_gameMatrice);
                }

                //New line so the value of the Alien go back to the first column alien distance
                xAlien = _firstXAlienDistance;
            }
        }

        /// <summary>
        /// Check if the index of the Missile is in the index of the Alien who is in life, previously added to the list
        /// </summary>
        /// <param name="missileXIndex">Horizontal index of the missile in the game matrix</param>
        /// <param name="missileYIndex">Horizontal index of the missile in the game matrix</param>
        public bool ControlAlienShoot(int missileXIndex, int missileYIndex)
        {
            // Go threw the list of alien in life
            foreach(Alien alien in lstAlienInLife)
            {
                //
                if (alien.checkMissileHitAlien(missileXIndex, missileYIndex))
                {
                    // Increase score info
                    _scoreInfo.IncreaseScore();
                    // Alien got shot
                    return true;
                }
            }
            // No alien got shot
            return false;
        }

        /// <summary>
        /// Add to a list every alien that is still a live, give information back if no more Alien are in life
        /// </summary>
        /// <returns>true if no more aliens are in life</returns>
        public bool NoAlienInLife()
        {
            //Clear the list 
            lstAlienInLife.Clear();

            //Go threw all the Alien of the board
            for (int i = 0; i < _boardAlien.GetLength(0); i++)
            {
                for (int j = 0; j < _boardAlien.GetLength(1); j++)
                {
                    // Add Alien to list of Alien if it is in life
                    if(_boardAlien[i, j].AlienLife>0)
                    {
                        lstAlienInLife.Add(_boardAlien[i, j]);                        
                    }              
                }
            }
            // no more alien in life, the user win
            if (lstAlienInLife.Count == 0)
            {
                return true;
            }
            // Some alien are still in life
            else
            {
                return false;
            }
        }



        /// <summary>
        /// Choose randomly a an alien in life in the list
        /// </summary>
        public void ShootingAlienPosition()
        {
            Random rnd = new Random();
            // Random index of the list of Alien who are still in life 
            _rndIndexAlien = rnd.Next(lstAlienInLife.Count);    
        }

    

        /// <summary>
        /// Get the horizontal position of the Alien shooter
        /// </summary>
        /// <returns>horizontal index of where the Alien will shoot</returns>
        public int AlienXshootPosition()
        {
            return lstAlienInLife[_rndIndexAlien].CannonXAlien();
        }
        /// <summary>
        /// Get the veritcal position of the Alien shooter
        /// </summary>
        /// <returns>vertical index of where the Alien will shoot</returns>
        public int AlienYshootPosition()
        {
            return lstAlienInLife[_rndIndexAlien].CannonYAlien();
        }
        


        /// <summary>
        /// Aliens moving towards left and right and downn, set the direction and change the first alien horizontal and veritcal index
        /// </summary>
        public void MoveAlien()
        {
            // Change the type of the Alien each time they move
            if (_counter % 2 == 0)
            {
                AlienTypeMove();
            }
            else
            {
                AlienTypeMovement();
            }

            // if hasnt reach the maximum distance going down it continues to go down
            if (WallAlienDistance())
            {
                // Move verticaly
                SetVerticalDirection();
            }
            // Move horizontally
            SetHorizontalDirection();

            // Increment counter for the movement type
            _counter++;
        }

      

        /// <summary>
        /// Set if the alien move to left or right
        /// </summary>
        private void SetHorizontalDirection()
        {
            // First Alien is at the maximum left need to move to right now
            if (_firstXAlienDistance == 0)
            {
                //Go to right
                _aliensMovingRight = true;
            }
            // Last Alien is at the maximum right need to move left 
            else if (_indexHorizontalLastAlien == _gameMatrice.GameMatrix.GetLength(1)-1)
            {
                //Go to left
                _aliensMovingRight = false;  
            }
            // Aliens hasn t moved down move to the side, if not wait next "turn"
            if(_aliensMovedDown == false)
            {
                MoveHorizontally();
            }     
        }

        /// <summary>
        /// Move left or right second to direction, change index of the first Alien
        /// </summary>
        private void MoveHorizontally()
        {
            // Aliens move to left
            if (_aliensMovingRight == false)
            {
                _firstXAlienDistance--;
            }
            // Aliens move to right
            if (_aliensMovingRight == true)
            {
                _firstXAlienDistance++;
            }
        }

        /// <summary>
        /// Move alien verticall(only goes down)
        /// </summary>
        private void MoveVertically()
        {
            // In this configuration the Alien only moves from down
            this._firstAlienDistanceTop++;
        }

        /// <summary>
        /// Set if the Aliens move down only when the hit the side of the console 
        /// </summary>
        private void SetVerticalDirection()
        {
            // the Alien hit the side and hasn't move down the turn before
            if ((this._firstXAlienDistance == 0 | _indexHorizontalLastAlien == _gameMatrice.GameMatrix.GetLength(1) - 1) && _aliensMovedDown == false)
            {
                 MoveVertically();
                //the alien has mooved so we know that it has only to move to the side until the next hit
                _aliensMovedDown = true;
            }
            else
            {
                //the Alien hasn't moved the turn before so he can move horizontally
                _aliensMovedDown = false;
            }
        }
        
        /// <summary>
        /// Check if Aliens have moved to the vertical down limit
        /// </summary>
        /// <returns>true if can not go further down</returns>
        private bool WallAlienDistance()
        {
            // If Alien has reach the limit distance, It cannot go down furthermore
            if (_indexVerticalLastAlien < LimitDistanceAliensFromBottom)
            {
                // Cant go down anymore
                return true;
            }

            _aliensMovedDown = false;
            // Can still go down
            return false;
        }




        /// <summary>
        /// Change alien type, change the ASSCI characther of each alien, for the impression of a movement
        /// </summary>
        private void AlienTypeMove()
        {
            //put the coordinate insinde the matrix
            for (int i = 0; i < _boardAlien.GetLength(0); i++)
            {
                for (int j = 0; j < _boardAlien.GetLength(1); j++)
                {
                    // three first line
                    if (i < 3)
                    {
                        _boardAlien[i, j].indexAlienType = 1;
                    }
                    // fourth line
                    else if (i == 3)
                    {
                        _boardAlien[i, j].indexAlienType = 3;
                    }
                    // fifth and last line
                    else
                    {
                        _boardAlien[i, j].indexAlienType = 5;
                    }
                }
            }
        }

        /// <summary>
        /// Change alien type, change the ASSCI characther of each alien, for the impression of a movement
        /// </summary>
        private void AlienTypeMovement()
        {
            //put the coordinate insinde the matrix
            for (int i = 0; i < _boardAlien.GetLength(0); i++)
            {
                for (int j = 0; j < _boardAlien.GetLength(1); j++)
                {
                    // three first line
                    if (i < 3)
                    {
                        _boardAlien[i, j].indexAlienType = 0;
                    }
                    // fourth line
                    else if (i == 3)
                    {
                        _boardAlien[i, j].indexAlienType = 2;
                    }
                    // fifth and last line
                    else
                    {
                        _boardAlien[i, j].indexAlienType = 4;
                    }
                }
            }
        }

    }
}
