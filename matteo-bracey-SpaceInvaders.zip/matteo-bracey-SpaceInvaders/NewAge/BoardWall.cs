﻿// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Control the vertical index of the different wall who are stored in an array, controls if a missile or a shot has hit one of the wall

namespace NewAge
{
    class BoardWall
    {

        // Number of the Wall
        private int _nbOfWall;

        // index verical always the same for the four walls
        public int IndexWallY { get; }

        // Array of walls
        private Wall[] _boardOfWall;

        //Spaceship dimension
        private char[,] _arrSpaceShip;

        // Bricks dimension
        private Wall _wall = new Wall();


        // Main game matrice
        private GameMatrice gameMatrice;

        public BoardWall()
        {

        }

        /// <summary>
        /// Set the number of wall and vertical index of the walls
        /// </summary>
        /// <param name="gameMatriceA">main game matrice</param>
        /// <param name="arrCharSpaceShipP">array of the spaceship </param>
        public BoardWall(GameMatrice gameMatriceA, char [,] arrCharSpaceShipP )
        {

            _nbOfWall = 4;

            //to have space dimensionn
            _arrSpaceShip = arrCharSpaceShipP;

            //main game matrice
            gameMatrice = gameMatriceA;

            // Create an array of Wall object 
            _boardOfWall = new Wall[_nbOfWall];

            //Index of the wall veritcal position accroding to spaceship height and the distance between them (2) 
            IndexWallY = gameMatrice.GameMatrix.GetLength(0) - _arrSpaceShip.GetLength(0) - _wall.WallHeight - 2;
            
            // Initialize the array of Wall
            InitiateArray();

            // Set vertical and horizontal of each wall
            SetWallIndex();

            // Write the wall in the main game matrice
            WriteWall();
        }

        /// <summary>
        /// Fill the array with the wall object passing the main matrice in charachter
        /// </summary>
        private void InitiateArray()
        {
            for (int i = 0; i < _boardOfWall.Length; i++)
            {
                _boardOfWall[i] = new Wall(gameMatrice);
            }
        }
        
        /// <summary>
        /// Store in each wall of the array the horizontal and vertical address
        /// </summary>
        public void SetWallIndex()
        {
            // Calcluate the distance between each wall according to the game matrice width and the number of wall
            int _wallDistance = gameMatrice.GameMatrix.GetLength(1) / (_nbOfWall + 1);

            // for each wall set and assign the horizontal and vertical index
            for (int wallNumber = 0; wallNumber < _boardOfWall.Length; wallNumber++)
            {
                _boardOfWall[wallNumber].IndexWallX = _wallDistance * (wallNumber + 1) - _wall.ArrWallChar.GetLength(1) / 2;          
                _boardOfWall[wallNumber].IndexWallY = IndexWallY;
            }
        }

        /// <summary>
        /// Reduce wall life in place of impact
        /// </summary>
        /// <param name="missileYCoord">take the vertical coordinate of the missile</param>
        /// <param name="missileXCoord">take the horizontal coordinate of the missile</param>
        /// <returns>true if a missile has impact a wall still in life</returns>
        public bool WallImpact(int missileXCoord, int missileYCoord)
        {
            // check each wall of the in the array of wall object BoradWall
            for (int i = 0; i < _boardOfWall.Length; i++)
            {
                // if a missile hit a brick return true
                if (_boardOfWall[i].CheckAllBricks(missileXCoord, missileYCoord))
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Write the four wall in matrice
        /// </summary>
        /// <param name="newAgeGameMatrice"></param>
        public void WriteWall()
        {
            // go threw all the wall in the array
            for (int i = 0; i < _boardOfWall.Length; i++)
            {
                // Call the method of the wall to write his brick in the matrice
                _boardOfWall[i].WriteBricks();
            }
        }
    }
}
