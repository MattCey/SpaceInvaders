﻿using System.Collections.Generic;
using System.Linq;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: There is three different type of alien, each one has a two different style: still and moving, we compare the position of each Alien character with
// a missile if it hits one

namespace NewAge
{
    class Alien
    {
        // three type of alien different alien the alien will be slightly different when they will be moving
        
        //First type of alien
        private char[,] _alienOne;
        private char[,] _alienOneMove;

        // Second type of alien
        private char[,] _alienTwo;
        private char[,] _alienTwoMove;

        // Third type of alien
        private char[,] _alienThree;
        private char[,] _alienThreeMove;

        // life of each alien
        public int AlienLife { get; private set; }

        // List of the different alien
        public List<char[,]> _lstAlienType { get; }

        // index for the type of Alien 
        public int indexAlienType { get; set; }

        // List of array with the index (x,y) of each charachter of the Alien
        public List<int[]> lstArrIndexCharAlien = new List<int[]>();

        // Index x in the gamematrice of the first Char of the Alien
        public int IndexXAlien { get; set; }

        // Index y in the gamematrice of the first Char of the Alien
        public int IndexYAlien { get; set; }

        // Main game matrice
        public GameMatrice gameMatrice;
        public Alien()
        {

        }

        /// <summary>
        /// Set the alien different type, set this alien type and life
        /// </summary>
        /// <param name="alienTypeIndex"></param>
        public Alien(int alienTypeIndex, GameMatrice gameMatriceA)
        {
            gameMatrice = gameMatriceA;

            // Set the alien type
            _alienOne = new char[2, 5] { { '{', '@', '@', '@', '}' }, { '/', '"', ' ', '"', '\\' } };
            _alienOneMove = new char[2, 5] { { '{', '@', '@', '@', '}' }, { ' ', '\\', ' ', '/', ' ' } };
            _alienTwo = new char[2, 5] { { 'd', 'O', 'O', 'O', 'b' }, { '^', '/', ' ', '\\', '^' } };
            _alienTwoMove = new char[2, 5] { { 'd', 'O', 'O', 'O', 'b' }, { '~', '|', ' ', '|', '~' } };
            _alienThree = new char[2, 5] { { '/', 'M', 'M', 'M', '\\' }, { '|', '~', ' ', '~', '|' } };
            _alienThreeMove = new char[2, 5] { { '/', 'M', 'M', 'M', '\\' }, { '\\', '~', ' ', '~', '/' } };

            // Add all type to the list
            _lstAlienType = new List<char[,]>();
            _lstAlienType.Add(_alienOne);
            _lstAlienType.Add(_alienOneMove);
            _lstAlienType.Add(_alienTwo);
            _lstAlienType.Add(_alienTwoMove);
            _lstAlienType.Add(_alienThree);
            _lstAlienType.Add(_alienThreeMove);

            // Set alien Life
            AlienLife = 1;

            // this alien type index
            indexAlienType = alienTypeIndex;
        }

        /// <summary>
        /// Write this alien  in the game matrice according to his type, vertical and horizontal index
        /// </summary>
        /// <param name="gameMatrice">matrice of the game</param>
        public void WriteAlien(GameMatrice gameMatrice)
        {
            // Only if alien is living
            if (AlienLife > 0)
            {
                for (int i = 0; i < _lstAlienType[indexAlienType].GetLength(0); i++)
                {
                    for (int j = 0; j < _lstAlienType[indexAlienType].GetLength(1); j++)
                    {
                        // Put inside the gameMatrix the charachter according to the Alien type and his vertical and horizontal index
                        gameMatrice.GameMatrix[IndexYAlien + i, IndexXAlien + j] = _lstAlienType[indexAlienType][i, j];
                    }
                }
            }
        }


        /// <summary>
        /// Verify if the missile is on one of the same place, we compare the array of the missile with the array of the index x y of the Alien Characters
        /// </summary>
        /// <param name="xIndexMissile">horizontal index of the missile in the main matrice</param>
        /// <param name="yIndexMissile">vertical index of the missile in the main matrice</param>
        /// <returns>true if the missile is on the same place of any charachter of the alien </returns>
        public bool checkMissileHitAlien(int xIndexMissile, int yIndexMissile)
        {

            for (int i = 0; i < _lstAlienType[indexAlienType].GetLength(0); i++)
            {
                for (int j = 0; j < _lstAlienType[indexAlienType].GetLength(1); j++)
                {
                    //Create array of index horizontal and vertical
                    if(xIndexMissile == IndexXAlien + j &&  yIndexMissile == IndexYAlien + i)
                    {
                        AlienLife--;
                        return true;
                    }
                }
            }
            return false;

        }

      

        /// <summary>
        /// Get the horizontal position of the Alien where it will be shooting
        /// </summary>
        /// <returns>The width of the </returns>
        public int CannonXAlien()
        {
            // We add to the horizontal position of the Alien half of his witdh
            return IndexXAlien + _lstAlienType[indexAlienType].GetLength(1) / 2;
        }
        /// <summary>
        /// Get the vertical position of the Alien where it will be shooting
        /// </summary>
        /// <returns></returns>
        public int CannonYAlien()
        {
            // We add to vertical index of the Alien the height 
            return IndexYAlien + _lstAlienType[indexAlienType].GetLength(0);
        }
    }
}
