﻿using System;
using System.Threading;
using System.Collections;

namespace NewAge
{

    class Program
    {
        static void Main(string[] args)
        {

            // Set console window size the, value of height and width, these values can not be shrink (because of the menu interface) but they can be raise
            Console.SetWindowSize(160, 55);
            Console.CursorVisible = false;
            GameControl gameControl = new GameControl();

        }
    }
}
