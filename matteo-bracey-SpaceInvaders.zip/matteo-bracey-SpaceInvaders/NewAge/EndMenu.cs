﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Display the end menu, store the player choice to restart, reset or quit the game

namespace NewAge
{
    class EndMenu
    {
        // Time before displaying the menu 
        private int _millisecondsBeforeEndMenu;

        // set a string with restart, reset or quit
        public string UserDecision { get; private set; }

        // player current score
        private int _userScore;

        // player highest score
        private int _userHighScore;
      
        /// <summary>
        /// 
        /// </summary>
        /// <param name="actualScore">player current score</param>
        /// <param name="PlayeHighscore">player highest score</param>
        public EndMenu(int actualScore, int PlayeHighscore)
        {
            _userScore = actualScore;
            _userHighScore = PlayeHighscore;

            // Time before showing the menu to let know the player how he lost
            _millisecondsBeforeEndMenu = 2000;

            // Print end menu in the console
            DisplaysEndMenu();

            //Player input key for choosing to restart, reset or quit the game
            playerKey();
        }

        /// <summary>
        /// Print the end menu in the console
        /// </summary>
        public void DisplaysEndMenu()
        {
            // time to player see the end game
            Thread.Sleep(_millisecondsBeforeEndMenu);

            // Erase the current console
            Console.Clear();
            
            //Print the score informations and the choice that can make the player
            Console.WriteLine($"\n \n Your Score is : {Convert.ToString(_userScore)}  Your HighScore is : {Convert.ToString(_userHighScore)}");
            Console.Write("\n Press [r] to restart the game, [t] to reset the game (new configuration) or [q] to quit the application  :");
          
        }

        /// <summary>
        /// Set a string value according to the player choice
        /// </summary>
        private void playerKey()
        {
            ConsoleKeyInfo inputUser;

            do
            {
                //Player key input
                    inputUser = Console.ReadKey();

                    switch (inputUser.Key)
                    {
                        case ConsoleKey.R:
                            UserDecision = "restart";
                            break;
                        case ConsoleKey.T:
                            UserDecision = "reset";
                            break;
                        case ConsoleKey.Q:
                            UserDecision = "quit";                       
                            break;
                    }

                // Player in loop if he has not put one of the right key
            } while (!(inputUser.Key == ConsoleKey.Q || inputUser.Key == ConsoleKey.T || inputUser.Key == ConsoleKey.R));

        }
    }
}
