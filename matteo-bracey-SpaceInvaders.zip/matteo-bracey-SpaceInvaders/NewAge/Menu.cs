﻿using System;
using System.Threading;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Display the menu and set the configuration of difficulty and sound with the players inputs

namespace NewAge
{
    class Menu
    {
        //y position of cursor for printing "Play"
        private int _cursorTopPositionPlay;
        // y position of cursor for printing "SELECT DIFFICULTY", "EASY" and "HARD"
        private int _cursorTopPositionDifficulty;

        // x position of cursor for printing "SELECT DIFFICULTY" and "SOUND"
        private int _cursorLeftPositionParam;

        // x position of cursor for printing "EASY" and "ON"
        private int _cursorLeftPositionFirstParam;

        // x position of cursor for printing "HARD" and "OFF"        
        private int _cursorLeftPositionSecondParam;

        // y position of cursor for printing "SOUND", "ON" and "OFF"
        private int _cursorTopPositionSound;

        // title color
        private ConsoleColor _titleColor = ConsoleColor.Red;

        // parameter color
        private ConsoleColor _paramColor = ConsoleColor.DarkRed;

        // selected parameter color
        private const ConsoleColor _selectedParamColor = ConsoleColor.Green;

        // unselected parameter color
        private const ConsoleColor _unselectedParamColor = ConsoleColor.White;

        // The game parameter are represented in an 2D array
        // In the first line represent the word PLAY [0,0] and [0,1]
        // In the second line the word EASY[1,0] and HARD[1,1]
        // In the third line the word ON[2,0] and OFF[2,1]
        private int[,] _tableConfig = new int[3, 2];

        // vertical and horizontal index in the table configuration, by default the player is on the ON asscii word
        private int _indexYConfig;
        private int _indexXConfig;

        // key input by the user
        private ConsoleKeyInfo _inputPlayer;

        // Game Configuration by default is the difficulty is easy and the sound is on
        // difficulty is false for easy and true for hard
        public bool DifficultyHard { get; private set; }
        // Sound is false for on and true for off
        public bool SoundOn { get; private set; }

        /// <summary>
        /// Set position of cursor for the menu words, set the configuration options by defalut and print the menu
        /// </summary>
        public Menu()
        {
            // horizontal cursor position for printing "SELECT DIFFICULTY" and "SOUND"
            _cursorLeftPositionParam = 5;

            // Set horizontal cursor position of the param "ON" and "EASY"
            _cursorLeftPositionFirstParam = _cursorLeftPositionParam + 65;

            // Set horizontal cursor position of the param "OFF" and "HARD"
            _cursorLeftPositionSecondParam = _cursorLeftPositionFirstParam + 40;

            // vertical and horizontal index in the table configuration, by default the player is on the "ON" asscii word [2,0]
            _indexYConfig = 2;
            _indexXConfig = 0;

            //Default parameters, the selected parameter by default in the menu
            //true is for easy difficulty
            this.DifficultyHard = false;

            //true is for sound on;
            this.SoundOn = true;

            // Print title and menu
            printMenu();
        }

        /// <summary>
        /// Print the menu in the console
        /// </summary>
        private void printMenu()
        {
            // For esthetic purpose
            Console.CursorVisible = false;

            // Print Title words
            printSpace();
            printInvaders();

            // We move the cursor postion for the next word (PLAY) and store it 
            _cursorTopPositionPlay = Console.CursorTop + 5;

            // Print the different words in the Console
            printPlay();
            printSelectDifficulty();
            printEasy();
            printDifficult();
            printSound();
            printOn();
            printOff();
        }

        /// <summary>
        /// Print the SPACE ASSCI word, in the middle of the console one line after one
        /// </summary>
        private void printSpace()
        {
            // Set the consoler cursorTop
            Console.CursorTop = 4;

            // Longest Line of the word SPACE,the lenghth will be used to set the word in the middle of the console 
            string titleSpace = ":::: ::    ::       ::   :::   ::: :::   :: ::::";
            // Set the foreground color
            Console.ForegroundColor = _titleColor;

            // Write the word SPACE in ASSCI charachter
            //Set the cursor according to the longest line of the SPACE title
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine(" @@@@@@   @@@@@@@    @@@@@@    @@@@@@@  @@@@@@@@");
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine("@@@@@@@   @@@@@@@@  @@@@@@@@  @@@@@@@@  @@@@@@@@");
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine("!@@       @@!  @@@  @@!  @@@  !@@       @@!");
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine("!@!       !@!  @!@  !@!  @!@  !@!       !@!");
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine("!!@@!!    @!@@!@!   @!@!@!@!  !@!       @!!!:!");
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine(" !!@!!!   !!@!!!    !!!@!!!!  !!!       !!!!!:");
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine("     !:!  !!:       !!:  !!!  :!!       !!:");
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine("    !:!   :!:       :!:  !:!  :!:       :!:");
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine(":::: ::    ::       ::   :::   ::: :::   :: ::::");
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine(":: : :     :         :   : :   :: :: :  : :: ::");
            cursorPositionTitle(title: titleSpace);
            Console.WriteLine();
        }

        /// <summary>
        /// Print the INVADERS ASSCI word, in the middle of the console one line after one
        /// </summary>
        private void printInvaders()
        {
            // Longest Line of the word INVADERS, the length will be used to set the word in the middle of the console 
            string titleInvaders = "!!:  !!:  !!!  :!:  !!:  !!:  !!!  !!:  !!!  !!:       !!: :!!        !:!";

            // Write the word INVADERS in ASCII charachters
            //Set the cursor according to the longest line of the INVADERS title
            cursorPositionTitle(title: titleInvaders);
            Console.WriteLine("@@@  @@@  @@@  @@@  @@@   @@@@@@   @@@@@@@   @@@@@@@@  @@@@@@@    @@@@@@");
            cursorPositionTitle(title: titleInvaders);
            Console.WriteLine("@@@  @@@@ @@@  @@@  @@@  @@@@@@@@  @@@@@@@@  @@@@@@@@  @@@@@@@@  @@@@@@@");
            cursorPositionTitle(title: titleInvaders);
            Console.WriteLine("@@!  @@!@!@@@  @@!  @@@  @@!  @@@  @@!  @@@  @@!       @@!  @@@  !@@");
            cursorPositionTitle(title: titleInvaders);
            Console.WriteLine("!@!  !@!!@!@!  !@!  @!@  !@!  @!@  !@!  @!@  !@!       !@!  @!@  !@!");
            cursorPositionTitle(title: titleInvaders);
            Console.WriteLine("!!@  @!@ !!@!  @!@  !@!  @!@!@!@!  @!@  !@!  @!!!:!    @!@!!@!   !!@@!!");
            cursorPositionTitle(title: titleInvaders);
            Console.WriteLine("!!!  !@!  !!!  !@!  !!!  !!!@!!!!  !@!  !!!  !!!!!:    !!@!@!     !!@!!!");
            cursorPositionTitle(title: titleInvaders);
            Console.WriteLine("!!:  !!:  !!!  :!:  !!:  !!:  !!!  !!:  !!!  !!:       !!: :!!        !:!");
            cursorPositionTitle(title: titleInvaders);
            Console.WriteLine(":!:  :!:  !:!   ::!!:!   :!:  !:!  :!:  !:!  :!:       :!:  !:!      !:!");
            cursorPositionTitle(title: titleInvaders);
            Console.WriteLine("::   ::   ::    ::::    ::   :::   :::: ::   :: ::::  ::   :::  :::: ::");
            cursorPositionTitle(title: titleInvaders);
            Console.WriteLine(":    ::    :      :       :   : :  :: :  :   : :: ::    :   : :  :: : :");
        }


        /// <summary>
        /// Place the cursor position according the length of the ASSCI word to make it in the center of the console
        /// </summary>
        /// <param name="title">longest string of the word</param>
        private void cursorPositionTitle(string title)
        {
            // Calculate the position to set of the cursor horizontally
            int distance = Console.WindowWidth / 2 - title.Length / 2;
            // Set the cursor, the vertical position do not need to change as we use WriteLine
            Console.SetCursorPosition(distance, Console.CursorTop);
            //Create a display effect each line appears one by one
            Thread.Sleep(100);
        }

        /// <summary>
        /// Print the PLAY ASSCI word, in the middle of the console one line after one
        /// </summary>
        /// <param name="color"></param>
        private void printPlay(ConsoleColor color = _unselectedParamColor)
        {

            // Store the cursor top position 
            Console.CursorTop = _cursorTopPositionPlay;
            //Set the color give by parameter
            Console.ForegroundColor = color;
            // Longest Line of the word Play,the lenghth will be used to set the word in the middle of the console 
            string playParam = " _____ _         ";

            // Write the word INVADERS in ASCII charachters
            //Set the cursor according to the longest line of the PLAY title
            cursorPositionTitle(title: playParam);
            Console.WriteLine(" _____ _         ");
            cursorPositionTitle(title: playParam);
            Console.WriteLine("|  _  | |___ _ _ ");
            cursorPositionTitle(title: playParam);
            Console.WriteLine("|   __| | .'| | |");
            cursorPositionTitle(title: playParam);
            Console.WriteLine("|__|  |_|__,|_  |");
            cursorPositionTitle(title: playParam);
            Console.WriteLine("           | ___|");
        }

        /// <summary>
        /// Print the SELECT DIFFICULTY ASSCI words
        /// </summary>
        private void printSelectDifficulty()
        {
            // Set the color, will be the same as the SOUND ASSCI word
            Console.ForegroundColor = _paramColor;

            //  we move the cursor postion for the next word (SELECT DIFFICULTY, EASY and HARD)
            Console.CursorTop = Console.CursorTop + 3;

            // Store the vertical cursor position, will be the same for the word ASSCI EASY and DIFFICULT
            _cursorTopPositionDifficulty = Console.CursorTop;

            // Print the word SELECT DIFFICULTY in ASCII charachters
            // Set the cursor, with the horizontal position of the cursor
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionParam);
            Console.WriteLine(" _____     _         _        _ _ ___ ___ _         _ _       ");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionParam);
            Console.WriteLine("|   __|___| |___ ___| |_    _| |_|  _|  _|_|___ _ _| | |_ _ _ ");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionParam);
            Console.WriteLine("|__   | -_| | -_|  _|  _|  | . | |  _|  _| |  _| | | |  _| | |");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionParam);
            Console.WriteLine("|_____|___|_|___|___|_|    |___|_|_| |_| |_|___|___|_|_| |_  |");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionParam);
            Console.Write("                                                        | ___|");
        }

        /// <summary>
        /// Print the EASY ASSCI word, the color will change if the usor has selected it, at the opening of the menu the EASY parameter is selected by default
        /// </summary>
        /// <param name="color">In wich we want to print EASY, set by default to selected</param>
        private void printEasy(ConsoleColor color = _selectedParamColor)
        {
            // Change the color according if the EASY word is selected or not
            Console.ForegroundColor = color;
            // Set the cursor position at the same heigth of SELECT DIFFICULTY
            Console.CursorTop = _cursorTopPositionDifficulty;

            // Print the word EASY in ASCII charachters
            // Set the cursor, with the horizontal position of the cursor
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionFirstParam);
            Console.WriteLine(" ______  ______   ______  __    _ ");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionFirstParam);
            Console.WriteLine("| |     | |  | | / |      | |  | |");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionFirstParam);
            Console.WriteLine("| |---- | |__| | '------. |_|__| |");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionFirstParam);
            Console.WriteLine("|_|____ |_|  |_|  ____|_/  ____|_|");
        }

        /// <summary>
        ///  Print the HARD ASSCI word, the color will change if the usor has selected it, at the opening of the menu the HARD parameter is not selected by default
        /// </summary>
        /// <param name="color">In wich we want to print HARD, set by default to unselected</param>
        private void printDifficult(ConsoleColor color = _unselectedParamColor)
        {
            // Change the color according if the HARD word is selected or not
            Console.ForegroundColor = color;
            // Set the cursor position at the same heigth of SELECT DIFFICULTY
            Console.CursorTop = _cursorTopPositionDifficulty;

            // Print the word HARD in ASCII charachters
            // Set the cursor, with the horizontal position of the cursor
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionSecondParam);
            Console.WriteLine(" _    _   ______   _____   _____  ");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionSecondParam);
            Console.WriteLine("| |  | | | |  | | | |  |_  | | | | ");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionSecondParam);
            Console.WriteLine("| |--| | | |__| | | |__| | | |  | |");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionSecondParam);
            Console.WriteLine("|_|  |_| |_|  |_| |_|  |_| |_|_|_|");
        }

        /// <summary>
        /// Print the SOUND ASSCI words
        /// </summary>
        private void printSound()
        {
            // Set the color, will be the same as the SELECT DIFFICULTY ASSCI word
            Console.ForegroundColor = _paramColor;

            //  we move the cursor postion for the next word (SOUND, ON and OFF)
            Console.CursorTop = Console.CursorTop + 5;

            // Store the vertical cursor position, will be the same for the word ASSCI ON and OFF 
            _cursorTopPositionSound = Console.CursorTop;

            // Print the word SOUND in ASCII charachters
            // Set the cursor, with the horizontal position of the cursor
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionParam);
            Console.WriteLine(".d88b. .d88b. 8    8 8b  8 888b.");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionParam);
            Console.WriteLine("YPwww. 8P  Y8 8    8 8Ybm8 8   8");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionParam);
            Console.WriteLine("    d8 8b  d8 8b..d8 8   8 8   8");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionParam);
            Console.WriteLine("`Y88P' `Y88P' `Y88P' 8   8 888P'");
        }

        /// <summary>
        /// Print the ON ASSCI word, the color will change if the usor has selected it, at the opening of the menu the EASY parameter is selected by default
        /// </summary>
        /// <param name="color">In wich we want to print EASY, set by default to selected</param>
        private void printOn(ConsoleColor color = _selectedParamColor)
        {
            // Change the color according if the ON word is selected or not
            Console.ForegroundColor = color;

            // Set the cursor position at the same heigth of SOUND
            Console.CursorTop = _cursorTopPositionSound;

            // Print the word ON in ASCII charachters
            // Set the cursor, with the horizontal position of the cursor
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionFirstParam);
            Console.WriteLine(" _____ _____ ");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionFirstParam);
            Console.WriteLine("|     |   | |");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionFirstParam);
            Console.WriteLine("|  |  | | | |");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionFirstParam);
            Console.WriteLine("|_____|_|___|");
        }

        /// <summary>
        /// Print the OFF ASSCI word, the color will change if the usor has selected it, at the opening of the menu the OFF parameter is not selected by default
        /// </summary>
        /// <param name="color">In wich we want to print OFF, set by default to unselected</param>
        private void printOff(ConsoleColor color = _unselectedParamColor)
        {
            // Change the color according if the OFF word is selected or not
            Console.ForegroundColor = color;

            // Set the cursor position at the same heigth of SOUND
            Console.CursorTop = _cursorTopPositionSound;

            // Print the word OFF in ASCII charachters
            // Set the cursor, with the horizontal position of the cursor
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionSecondParam);
            Console.WriteLine(" _____ _____ _____ ");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionSecondParam);
            Console.WriteLine("|     |   __|   __|");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionSecondParam);
            Console.WriteLine("|  |  |   __|   __|");
            cursorPositionConfig(cursorLeftPosition: _cursorLeftPositionSecondParam);
            Console.WriteLine("|_____|__|  |__|   ");

        }

        /// <summary>
        /// Set the cursor position in the console
        /// </summary>
        /// <param name="cursorLeftPosition">cursor horizontal position</param>
        private void cursorPositionConfig(int cursorLeftPosition)
        {
            // doesnt change the current vertical position
            Console.SetCursorPosition(cursorLeftPosition, Console.CursorTop);
        }

        /// <summary>
        /// Player can navigate threw the configuration with the arrow key and change sound and difficulty option
        /// </summary>
        public void selectParam()
        {
            do
            {
                // Store the key input by the user
                _inputPlayer = Console.ReadKey();

                // Change the two index horizontal and vertical
                playerKeyInput(infoKey: _inputPlayer);

                // Change the display and the configuration according the two index
                ConfigurationAndDisplay();

                // Player must be on the Play(first row) and must tap the Enter key
            } while (!(_inputPlayer.Key == ConsoleKey.Enter & _indexYConfig == 0));
        }

        /// <summary>
        /// Will change the index values, to navigate threw the configuration menu
        /// </summary>
        /// <param name="infoKey">Key Input by the player</param>
        private void playerKeyInput(ConsoleKeyInfo infoKey)
        {
            // the player can navigate threw the configuration with the help of some keys
            switch (infoKey.Key)
            {
                case ConsoleKey.RightArrow:

                    // can only move right if it is currently to the left column
                    if (_indexXConfig == 0)
                        _indexXConfig++;
                    break;
                case ConsoleKey.LeftArrow:

                    // can only move left if it is currently to the right column
                    if (_indexXConfig == 1)
                        _indexXConfig--;
                    break;
                case ConsoleKey.DownArrow:

                    // Can only move down if it is not currently on the last row
                    if (_indexYConfig < 2)
                        _indexYConfig++;
                    break;
                case ConsoleKey.UpArrow:

                    // Can only move down if it is not currently on the last row
                    if (_indexYConfig > 0)
                        _indexYConfig--;
                    break;
            }
        }

        /// <summary>
        /// Control every display, will change the display and configuration according to the two index values
        /// </summary>
        private void ConfigurationAndDisplay()
        {
            // Player is on the difficulty configuration second row
            if (_indexYConfig == 1)
            {
                // Display the difficulty configuration
                displayDifficultyConfiguration();
            }
            // Player is on the sound configuration third row
            else if (_indexYConfig == 2)
            {
                // Display the sound configuration
                displaySoundConfiguration();
            }
            // Player is on the first row
            else
            {
                // Display the play configuration
                printPlay(_selectedParamColor);
            }
        }

        /// <summary>
        /// Display the difficulty configuration, will change the color of the word HARD and EASY according if it is selected or not
        /// Change the difficult configutation according of the word selected
        /// </summary>
        private void displayDifficultyConfiguration()
        {
            // Player is on the left difficulty configuration -> easy
            if (_indexXConfig == 0)
            {
                //EASY ASSCI word will be print in the color of a selected parameter 
                printEasy(_selectedParamColor);

                //DIFFICULT ASSCI word will be print in the color of an unselected parameter
                printDifficult(_unselectedParamColor);

                //PLAY ASSCI word will be print in the color of an unselected parameter
                printPlay(_unselectedParamColor);

                // Set the diffulty to easy -> false
                DifficultyHard = false;
            }
            // Player is on the right difficulty configuration -> hard
            else
            {
                //EASY ASSCI word will be print in the color of an unselected parameter 
                printEasy(_unselectedParamColor);

                //DIFFICULT ASSCI word will be print the color of a selected parameter
                printDifficult(_selectedParamColor);

                //PLAY ASSCI word will be print in the color of an unselected parameter
                printPlay(_unselectedParamColor);

                // Set the diffulty to hard -> true
                DifficultyHard = true;
            }
        }

        /// <summary>
        /// Display the sound configuration, will change the color of the word ON and OFF according if it is selected or not
        /// Change the sound configutation according of the word selected
        /// </summary>
        private void displaySoundConfiguration()
        {
            // Player is on the left sound configuration -> on
            if (_indexXConfig == 0)
            {
                //ON ASSCI word will be print in the color of a selected parameter 
                printOn(_selectedParamColor);

                //OFF ASSCI word will be print in the color of an unselected parameter 
                printOff(_unselectedParamColor);

                // Set the sound to on -> true
                SoundOn = true;
            }
            // Player is on the right sound configuration -> off
            else
            {
                //ON ASSCI word will be print in the color of an unselected parameter 
                printOn(_unselectedParamColor);

                //OFF ASSCI word will be print in the color of a selected parameter 
                printOff(_selectedParamColor);

                // Set the sound to off -> false
                SoundOn = false;
            }
        }
    }
}
