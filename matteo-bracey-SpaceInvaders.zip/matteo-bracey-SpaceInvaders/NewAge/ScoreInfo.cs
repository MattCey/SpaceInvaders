﻿using System;
using System.Collections.Generic;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Display life and score information in the top of the console, also the horizontal bar who separates the score information area from the game area
// Store different value like the score, highscore, life of the SpaceShip...

namespace NewAge
{
    class ScoreInfo
    {
        // Number of life of the Spaceship 
        public int SpaceshipLife { get; private set; }

        // Score total of the game
        public int Score { get; private set; }

        // Score by Alien dead
        private int _pointsPerAlien;

        // Highscore set to zero at first game
        private int _intHighScore;

        // Position Cursor to write Score horizontal
        private int _cursorPostionScore;

        // String to display the highscore 
        private string _strHighScore;

        // String to display the score 
        private string _strScore;

        // String to display the palyer life
        private string _strLife;

        // Where the horizontal Border will be displayed, ! DO NOT CHANGE THIS VALUE !
        private int _heightOfTheBorder;

        // Color of the life display
        private ConsoleColor _lifeColor;

        // Color of the Score display
        private ConsoleColor _scoreColor;

        // List of the horizontal cursor position of each spaceship how will be print to represent life
        private List<int> _lstSpaceshipLifeDisplayPosition;

        //Spaceship dimension
        private char[,] _arrSpaceShip;


        /// <summary>
        /// Set the different property and fields and call different method to display all the score informations
        /// </summary>
        /// <param name="spaceshiplifeDifficulty">Spaceship life according to selected difficulty</param>
        /// <param name="previousHighScore">When the player restart or reset the game, HighScore of a previous game, if it is the first game it will be passed as 0</param>
        public ScoreInfo(int spaceshiplifeDifficulty, int previousHighScore, char[,] ArrCharSpaceShipP)
        {
            // Spaceship life depends on the difficulty mode selected by the player (easy or hard)
            SpaceshipLife = spaceshiplifeDifficulty;

            // Score total begins at 0
            Score = 0;

            // Points for each alien killed
            _pointsPerAlien = 20;

            // Previous HighScore stored, equal to 0 for the first game
            _intHighScore = previousHighScore;

            // Show score information 
            _strHighScore = "HIGHSCORE : ";
            _strScore = "SCORE : ";
            _strLife = "LIFE : ";

            // Where the horizontal Border will be displayed  !!!DO NOT CHANGE THIS VALUE !!!
            _heightOfTheBorder = 2;

            // Color of the life display
            _lifeColor = ConsoleColor.Magenta;

            // Color of the Score display
            _scoreColor = ConsoleColor.White;

            // Store the horizontal cursor position of all space ships print that represent a life, when the spaceShip lose a life the display will change, (each space ship represent one life) 
            _lstSpaceshipLifeDisplayPosition = new List<int>();

            _arrSpaceShip = ArrCharSpaceShipP;

            // Print the horizontal line that will separate the score area from the game area
            DisplayTopBorder();

            // Display the life in the score area
            DisplayLife();

            // Display the score and highscore in the score area
            DisplayHighScore();
        }



        /// <summary>
        /// Display the life in the score area, the life is displayed in the top left of the Console, each Life of the player will be represented by a print of the space ship
        /// </summary>
        public void DisplayLife()
        {
            Console.ForegroundColor = ConsoleColor.White;
            // Set the cursor position of to display the life information
            Console.SetCursorPosition(5, 0);

            Console.Write(_strLife);

            // Life information are displayed in red 
            Console.ForegroundColor = _lifeColor;

            // Store the current cursor position
            int xCursor = Console.CursorLeft;

            // Write the spaceship image
            for (int i = 0; i < SpaceshipLife; i++)
            {
                // Store each spaceship horizontal cursor position before the printing of spaceShip
                _lstSpaceshipLifeDisplayPosition.Add(xCursor);

                // Print the spaceship character at the specified
                PrintSpaceShip(spaceShipLifePosition: xCursor);

                // Store the next index, we add the widthc of the spaceship character and some space
                xCursor += 2 + _arrSpaceShip.GetLength(1);
            }
        }

        /// <summary>
        /// Print the space ship characters
        /// </summary>
        /// <param name="spaceShipLifePosition">Horizontal cursor position will change for each space ship print</param>
        private void PrintSpaceShip(int spaceShipLifePosition)
        {
            // Print the SpaceShip characters according to 2D array of charachters of the space ship
            for (int j = 0; j < _arrSpaceShip.GetLength(0); j++)
            {
                for (int k = 0; k < _arrSpaceShip.GetLength(1); k++)
                {
                    // Set the cursor in position
                    Console.SetCursorPosition(k + spaceShipLifePosition, j);
                    Console.Write(_arrSpaceShip[j, k]);
                }
            }
        }
 

        /// <summary>
        /// Print empty whitespace to erase characters in the console
        /// </summary>
        /// <param name="spaceShipLifePosition">Horizontal cursor position will change for each space ship print</param>
        private void PrintBlank(int spaceShipLifePosition)
        {
            // Print the SpaceShip characters according to 2D array of charachters of the space ship
            for (int j = 0; j < _arrSpaceShip.GetLength(0); j++)
            {
                for (int k = 0; k < _arrSpaceShip.GetLength(1); k++)
                {
                    //Put the position at the last Spaceship display
                    Console.SetCursorPosition(k + spaceShipLifePosition, j);

                    // Replace the current charachter by a space
                    Console.Write(" ");
                }
            }
        }

        /// <summary>
        /// Reduce the life of the spaceship and change the current display of life (suppresion of one spaceship)
        /// </summary>
        public void ReduceLife()
        {
            // reduce life of the spaceship
            SpaceshipLife--;

            // Only if there is at leat one space ship print in the score area
            if (SpaceshipLife >= 0)
            {
                // Erase a spaceship life in the score area 
                PrintBlank(_lstSpaceshipLifeDisplayPosition[SpaceshipLife]);
            }
        }

        /// <summary>
        /// Display a border to separate the game area from the score and life display
        /// </summary>
        private void DisplayTopBorder()
        {
            // According to the width of the console
            for (int i = 0; i < Console.WindowWidth; i++)
            {
                Console.SetCursorPosition(i, _heightOfTheBorder);
                Console.Write("‗");
            }
        }

        /// <summary>
        /// Display Score and Highscore in the top right of the console in the score area
        /// </summary>
        private void DisplayHighScore()
        {
            // Life information are displayed in red 
            Console.ForegroundColor = _scoreColor;

            // Set cursor position for the HighScore
            Console.SetCursorPosition(Console.WindowWidth - 45, 0);
            Console.Write(_strHighScore);

            // Print the current HighScore
            Console.Write(Convert.ToInt32(_intHighScore));

            // Set cursor position for the Score
            Console.SetCursorPosition(Console.WindowWidth - 25, 0);
            Console.Write(_strScore);

            // Store the Score cursor position to modify the score during the game
            _cursorPostionScore = Console.CursorLeft;

            // Print the curret Score
            Console.Write(Convert.ToInt32(Score));
        }

        /// <summary>
        /// Increase and print the score when it changes (Alien got hit by space ship missile)
        /// </summary>
        public void IncreaseScore()
        {
            // Increase score
            Score += _pointsPerAlien;

            // Print the current score
            Console.SetCursorPosition(_cursorPostionScore, 0);
            Console.Write(Convert.ToInt32(Score));
        }


    }

}
