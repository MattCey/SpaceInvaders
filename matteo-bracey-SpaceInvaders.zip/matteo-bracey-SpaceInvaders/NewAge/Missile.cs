﻿using System.Collections.Generic;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Create and move the missile in the main game matrice, checks if a missile has hit a wall, an alien, the top border
// Verify if an alien shoot has had a collision with one of the missile, produce a sound when missile is launched (if sound option is on)
namespace NewAge
{
    class Missile
    { 
        // list of the x horizontal index of Missile
        private List<int> _listXPositionMissile;

        // list of the y vertical index of Missile
        private List<int> _listYPositionMissile;

        // ASSCI charachter of the missile
        private const char _MISSILE_SYMBOLE = '$';

        // ASSCI charachter of the missile explosion
        private const char _MISSILE_EXPLOSION = '*';

        public char _missileSpaceShip;
        public char _missileExplosion;

        // Horizontal index of the missile in the main game matrice
        private int _xPositionMissile;

        // Vertical index of the missile in the main game matrice
        private int _yPositionMissile;

        // Get the Wall index
        private BoardWall _boardWall;

        // Get the aliens index and control shooting
        private BoardAlien _boardAlien;

        //Get the spaceship cannon position (where it launch the missile)
        private SpaceShip _spaceShip;

        // Main game matrice
        private GameMatrice _gameMatrice;

        // Make a noise when the spaceship launch a missile
        private Soundtrack _soundtrack;

        // Get the dimension of the wall and the ASSCI character of the bricks
        private Wall _wall = new Wall();
        
        // Get the Alien shoot ASCII charachter
        private Shoots _shoots = new Shoots();


        /// <summary>
        /// Constructor made if there is the no sound option because no soundtrack object is created
        /// </summary>
        /// <param name="boardWall">wall position and character</param>
        /// <param name="boardAlien">Aline position and character</param>
        /// <param name="spaceShip">space ship position </param>
        /// <param name="gameMatriceA">main game matrice</param>
        public Missile(BoardWall boardWall, BoardAlien boardAlien, SpaceShip spaceShip,  GameMatrice gameMatriceA)
        {
            // Intialise different variable   
            _listXPositionMissile = new List<int>();
            _listYPositionMissile = new List<int>();
            _missileSpaceShip = _MISSILE_SYMBOLE;
            _missileExplosion = _MISSILE_EXPLOSION;
            _boardWall = boardWall;
            _boardAlien = boardAlien;
            _spaceShip = spaceShip;
            _gameMatrice = gameMatriceA;

        }

        /// <summary>
        /// Constructor made if there is the sound option  is on because a soundtrack object is created
        /// </summary>
        /// <param name="boardWall">wall position and character</param>
        /// <param name="boardAlien">Alien position and character</param>
        /// <param name="spaceShip">space ship position </param>
        /// <param name="gameMatriceA">main game matrice</param>
        /// /// <param name="soundtrackA">soundtrack to make sound when the alien shoot</param>
        public Missile(BoardWall boardWall, BoardAlien boardAlien, SpaceShip spaceShip, GameMatrice gameMatriceA, Soundtrack soundtrackA)
        {
            // Intialise different variable  
            _listXPositionMissile = new List<int>();
            _listYPositionMissile = new List<int>();
            _missileSpaceShip = _MISSILE_SYMBOLE;
            _missileExplosion = _MISSILE_EXPLOSION;
             _gameMatrice = gameMatriceA;
            _boardWall = boardWall;
            _boardAlien = boardAlien;
            _spaceShip = spaceShip;
            _soundtrack = soundtrackA;
        }

        /// <summary>
        /// Define the missile index in the game matrice, each missile have index vertical and horizontal who are stored in two lists and will change position over time
        /// Create a sound effect
        /// </summary>
        public void NewMissile()
        {

            // Position of the missile when the player launch a missile, get index of where the cannon of the spaceship is in the game matrice
            _xPositionMissile = _spaceShip.IndexXSpaceShipCannon();
            _yPositionMissile = _spaceShip.IndexYSpaceShipCannon();

            //Add the missile in the list
            _listXPositionMissile.Add(_xPositionMissile);
            _listYPositionMissile.Add(_yPositionMissile);

            // If sound option is on 
            if (_soundtrack != null)
            {
                // make a noise of a missile
                _soundtrack.SoundMissile();
            }
        }

        /// <summary>
        /// Change the vertical position of the missile as they go up, check if they hit an alien, a brick of a wall or the top border
        /// </summary>
        public void WriteMissileMoves()
        {
            // Change each missile vertical index in the list
            for (int i = 0; i < _listXPositionMissile.Count; i++)
            {
                //Write the position in the main game matrice
                _gameMatrice.GameMatrix[_listYPositionMissile[i], _listXPositionMissile[i]] = this._missileSpaceShip;

                // Change missile vertical index
                _listYPositionMissile[i] -= 1;

                //WALL
                //Missile is in Wall Vertical Zone
                if (_listYPositionMissile[i] >= _boardWall.IndexWallY && _listYPositionMissile[i] < _boardWall.IndexWallY + _wall.ArrWallChar.GetLength(0))
                {
                    //The missile is on a Wall that is still in life define by the two wall bricks character
                    if (_gameMatrice.GameMatrix[_listYPositionMissile[i], _listXPositionMissile[i]] == _wall.WallOne
                        || _gameMatrice.GameMatrix[_listYPositionMissile[i], _listXPositionMissile[i]] == _wall.WallTwo)
                    {
                        //If the missile has impacted a Wall 
                        if (_boardWall.WallImpact(missileXCoord: _listXPositionMissile[i], missileYCoord: _listYPositionMissile[i]))
                        {
                            //We remove the missile it has hit a wall
                            RemoveMissile(i);
                            // We go to the next missile
                            break;
                        }
                    }
                }
                //ALIEN
                //Missile is in Alien Vertical Zone
                if (_listYPositionMissile[i] <= _boardAlien.LimitDistanceAliensFromBottom && _listYPositionMissile[i] >= _boardAlien._firstAlienDistanceTop)
                {
                    //missile hit an Alien, any charachater in the area except an alien shot
                    if (_gameMatrice.GameMatrix[_listYPositionMissile[i], _listXPositionMissile[i]] != '\0' &&
                        _gameMatrice.GameMatrix[_listYPositionMissile[i], _listXPositionMissile[i]] != _shoots.SHOOT_SYMBOLE)
                    {
                        // if an  Alien got shot
                        if (_boardAlien.ControlAlienShoot(missileXIndex: _listXPositionMissile[i], missileYIndex: _listYPositionMissile[i]))
                        {
                            // We remove the missile it has hit an alien
                            RemoveMissile(listIndex: i);

                            // We go to the next missile
                            break;
                        }
                    }
                }
                // Missile hit is on the top border and explode
                if (_listYPositionMissile[i] == 0)
                {
                    //Write Explosion in matrix
                    _gameMatrice.GameMatrix[_listYPositionMissile[i], _listXPositionMissile[i]] = this._missileExplosion;

                    // We remove the missile it has hit an alien
                    RemoveMissile(listIndex: i);

                    // We go to the next missile
                    break;
                }
            }
        }

        /// <summary>
        /// Missile hit something and is removed form the list
        /// </summary>
        /// <param name="listIndex">index of the missile same in the horizontal and vertical list</param>
        private void RemoveMissile(int listIndex)
        {
            // Remove Missile from the two list
            _listXPositionMissile.RemoveAt(listIndex);
            _listYPositionMissile.RemoveAt(listIndex);
        }

        /// <summary>
        /// Check if the shoot is in the same place of the missile
        /// </summary>
        /// <param name="xShoot">Alien shoot horizontal index</param>
        /// <param name="yShoot">Alien shoot vertical index</param>
        /// <returns>true if missile and shoot had an impact</returns>
        public bool MissileShootImpact(int xShoot, int yShoot)
        {
            // Go threw all missile to see wich shoot is in the same place of the missile
            for (int i = 0; i < _listXPositionMissile.Count; i++)
            {
                // check if the position of the missile is in the same place of the shoot, -1 because the missile changed index see line 70
                if (_listYPositionMissile[i] == yShoot-1 && _listXPositionMissile[i] == xShoot)
                {
                    // remove missile
                    RemoveMissile(i);
                    // Impact
                    return true;
                }
            }
            // No impact
            return false;
        }
    }
}
