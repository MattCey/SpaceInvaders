﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Set and change the spaceship index in the main game matrice

namespace NewAge
{
    class SpaceShip
    {
        // 2d array of ASSCI charachters of the spaceship
        public char[,] ArrCharSpaceShip { get; }

        // Horizontal index of the space ship (first char)
        public int IndexXSpaceShip {get; private set;}

        // Vertical index of the space ship (first char)
        public int IndexYSpaceShip { get; private set; }

        // Use to get the board game dimensions, and to set the spaceship into it
        private GameMatrice _gameMatrice;

        /// <summary>
        /// Set the spaceship charachters, set the intial index of the spaceship
        /// </summary>
        /// <param name="gameMatriceA">game matrice, board game to get the it s height and width</param>
        public SpaceShip(GameMatrice gameMatriceA)
        {
            // Set the game Matrice
            _gameMatrice = gameMatriceA;

            // Set the char of the SpaceShip in the 2d array
            ArrCharSpaceShip = new char [2, 7] { { '☻', '´', '/', '║', '\\', '═', '═' }, { '(', '@', '@', '@', '@', '@', ')' } };

            // Calculate and set the first horizontal and vertical index of the spaceship
            setSpaceShip();

            // Write spaceship in the main game matrice
            WriteSpaceship();
        }

        /// <summary>
        /// Set up the intial Spacship postion in the matrice, initial position in the middle
        /// </summary>
        /// <param name="gameMatrice">get the dimension of the matrix size</param>
        private void setSpaceShip()
        {
            // vertical index according to the height of the spaceship and the matrice
            IndexYSpaceShip = _gameMatrice.GameMatrix.GetLength(0) - ArrCharSpaceShip.GetLength(0);

            // horizontal index place in the middle of the matrice, according to the width of the spaceship and the matrice
            IndexXSpaceShip = _gameMatrice.GameMatrix.GetLength(1) / 2 - ArrCharSpaceShip.GetLength(1) / 2;
        }

        /// <summary>
        /// Increase the spaceship horizontal index in the game matrice, when the spaceship moves right 
        /// </summary>
        public void IncreaseIndexX()
        {
            this.IndexXSpaceShip++;
        }

        /// <summary>
        /// Decrease the spaceship horizontal index in the game matrice, when the spaceship moves left
        /// </summary>
        public void DecreaseIndexX()
        {
            this.IndexXSpaceShip--;
        }

        /// <summary>
        /// Set the spaceship array into game matrice
        /// </summary>
        public void WriteSpaceship()
        {
            // Write all the spaceship characters 
            for (int j = 0; j < ArrCharSpaceShip.GetLength(0); j++)
                for (int i = 0; i < ArrCharSpaceShip.GetLength(1); i++)
                {
                    //Set the spaceship array into game matrice according to the horizontal and vertical index 
                    _gameMatrice.GameMatrix[IndexYSpaceShip + j, IndexXSpaceShip + i] = ArrCharSpaceShip[j, i];
                }
        }

        /// <summary>
        /// Calculate and give the horizontal index of the spaceship cannon in the gamematrice
        /// </summary>
        /// <returns>horizontal index of the spaceship cannon where the missile will be launched</returns>
        public int IndexXSpaceShipCannon()
        {
            // Index of the cannon of the spaceship, addition of the index of the first chararchter of the spaceship plus the half of the length of the spaceship where the cannon is
            return IndexXSpaceShip + ArrCharSpaceShip.GetLength(1) / 2;
        }

        /// <summary>
        /// Calculate and give the vertical index of the spaceship cannon in the gamematrice
        /// </summary>
        /// <returns>vertical index of the spaceship cannon where the missile will be launched</returns>
        public int IndexYSpaceShipCannon()
        {
            // Decrease the index by one so the missile start the cell in top of the spaceship cannon
            return IndexYSpaceShip - 1;
        }
    }
}
