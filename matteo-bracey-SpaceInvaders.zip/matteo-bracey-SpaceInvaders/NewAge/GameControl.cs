﻿using System;
using System.Diagnostics;
using System.Threading;

// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Control the main game, create the different objects and calls their methods in the right order control the changes in the main game matrice
// Control the input of the player to move the space ship and to launch the missile

namespace NewAge
{
    class GameControl
    {
        // Menu of the game 
        private Menu _menu;

        // Soundtrack, main music and missile launched noise
        private Soundtrack _soundtrack;

        // Controls each wall
        private BoardWall _boardWall;

        // Main game matrice
        private GameMatrice _gameMatrice;

        // Information on life of the player, score and highscore
        private ScoreInfo _scoreInfo;

        // Controls each alien
        private BoardAlien _boardAlien;

        // Controls aliens shots
        private Shoots _shoots;

        // Control spaceship missile
        private Missile _missile;

        // Control the spaceship
        private SpaceShip _spaceship;

        // Menu at the end of the game to restart or quit the game, display player score
        private EndMenu _endMenu;

        // Stopwatch for the missile of the SpaceShip, the spaceship can only launch a new missile after a certain time
        private Stopwatch _stopwatch;

        // Count the number of loop in the main method
        private int _counter;

        // After how much iteration the Aliens will shoot, make the alien shoot faster the smaller the value of the modulo, will depend  on the difficulty
        private int _moduloShootsCounter;

        // Counter alien shot modulo value in easy mode 
        private int _moduloShootsEasyMode;

        // Counter alien shot modulo value in hard mode
        private int _moduloShootsHardMode;

        // After how much iteration the Alien will move, make the alien move faster the smaller the value of the modulo, will depend on the difficulty
        private int _moduloAlienMovementCounter;

        // Counter alien movement modulo value in easy mode 
        private int _moduloAlienMovementEasyMode;

        // Counter alien movement modulo value in hard mode
        private int _moduloAlienMovementHardMode;

        // numbers of life in easy mode
        private int _easyModeNbOfLife;

        // numbers of life in hard mode
        private int _hardModeNbOfLife;

        // highscore who will stay if the player restart the game
        private int _currentHighscore;



        /// <summary>
        /// Intialise variables
        /// </summary>
        public GameControl()
        {
            // Set variable for easy and hard mode
            _easyModeNbOfLife = 3;
            _hardModeNbOfLife = 1;
            _moduloShootsEasyMode = 28;
            _moduloShootsHardMode = 14;
            _moduloAlienMovementEasyMode = 10;
            _moduloAlienMovementHardMode = 6;

            // Set current highscore
            _currentHighscore = 0;

            // Create the menu
            _menu = new Menu();

            // Player chose the configuration of the menu easy or hard mode, sound on or off
            _menu.selectParam();

            // Create timer
            _stopwatch = new Stopwatch();

            // Create main matrice game 
            _gameMatrice = new GameMatrice();

            // Create new space ship
            _spaceship = new SpaceShip(gameMatriceA: _gameMatrice);

            // Set the life of the player, movement speed of the alien, occurence Aliens shot according to difficulty choice
            gameDifficulty();

            // Create the board of walls controlling the walls
            _boardWall = new BoardWall(gameMatriceA: _gameMatrice, arrCharSpaceShipP: _spaceship.ArrCharSpaceShip);

            // Create the board of Aliens controlling the aliens
            _boardAlien = new BoardAlien(gameMatriceA: _gameMatrice, boardWallA: _boardWall, scoreInfoA: _scoreInfo);

            // Create a soundobject and missile according to sound choice
            SoundObject();

            // Create shoots
            _shoots = new Shoots(boardWall: _boardWall, boardAlien: _boardAlien, spaceShip: _spaceship, gameMatriceA: _gameMatrice, missileA: _missile, scoreInfoA: _scoreInfo);

            //Print the main game matrice int
            _gameMatrice.SetPrintMatrix();

            // Start timer
            _stopwatch.Start();

            // Launch the game
            GameOn();
        }

        /// <summary>
        /// Set the speed of the movement of the Alien, the number of life of the player accroding to the player configuration choice
        /// </summary>
        private void gameDifficulty()
        {
            // Player select hard mode
            if (_menu.DifficultyHard)
            {
                // Create score with the number of life of the player
                _scoreInfo = new ScoreInfo(spaceshiplifeDifficulty: _hardModeNbOfLife, previousHighScore: _currentHighscore, ArrCharSpaceShipP: _spaceship.ArrCharSpaceShip);

                // Aliens shot a lot
                _moduloShootsCounter = _moduloShootsHardMode;

                // Alien move slowly
                _moduloAlienMovementCounter = _moduloAlienMovementHardMode;
            }
            // Player select easy mode
            else
            {
                // Create score with the number of life of the player
                _scoreInfo = new ScoreInfo(spaceshiplifeDifficulty: _easyModeNbOfLife, previousHighScore: _currentHighscore, ArrCharSpaceShipP: _spaceship.ArrCharSpaceShip);

                // Aliens shot sometimes
                _moduloShootsCounter = _moduloShootsEasyMode;

                // Aliens move fast
                _moduloAlienMovementCounter = _moduloAlienMovementEasyMode;
            }
        }


        /// <summary>
        /// Create a soundtrack object only if the player chose ON in the menu, this object is the pass to the missile object to make missile noise
        /// </summary>
        private void SoundObject()
        {
            // player configuration  sound on
            if (_menu.SoundOn)
            {
                // Create a soundtrack object only if player chose sound ON in the menu
                _soundtrack = new Soundtrack();

                // missile construction with the sound
                MissileCreation();
            }
            // player configuration sound off
            else
            {
                // missile construction without the sound
                MissileCreation();
            }
        }

        /// <summary>
        /// Missile creation depending if player chose sound on or off
        /// </summary>
        private void MissileCreation()
        {
            // player configuration  sound on
            if (_menu.SoundOn)
            {
                // Pass the soundtrack to the missile for the noise of the missile of the spaceship
                _missile = new Missile(boardWall: _boardWall, boardAlien: _boardAlien, spaceShip: _spaceship, gameMatriceA: _gameMatrice, soundtrackA: _soundtrack);
            }
            // player configuration sound off
            else
            {
                // missile construction without the sound
                _missile = new Missile(boardWall: _boardWall, boardAlien: _boardAlien, spaceShip: _spaceship, gameMatriceA: _gameMatrice);
            }
        }

        /// <summary>
        /// Launch the game until the player lose, then display the end menu
        /// </summary>
        public void GameOn()
        {
            // true if game ends
            bool gameEnd = false;
            do
            {
                // run the game until player space ship is dead
                gameEnd = moveSpaceShip();
            } while (gameEnd);

            // store current highscore 
            storeHighScore();

            // Display end menu, input player for the next game
            _endMenu = new EndMenu( actualScore :_scoreInfo.Score, PlayeHighscore: _currentHighscore);

            // Player start to restart, restart or quit the game
            NewGame();
        }

        /// <summary>
        /// Call the different objects to move in the main matrice, print the new game matrice after each iteration
        /// Control if the alien are all dead create new ones and if the player has no more life
        /// </summary>
        /// <returns>false if the player ship has no more life</returns>
        private bool moveSpaceShip()
        {
            // Check if some aliens are still in live, if not creates new one
            NewAliens();

            // player has no more life
            if (_scoreInfo.SpaceshipLife < 0)
            {
                return false;
            }

            // Move the spaceship or launch a missile accorfing to the pl
            InputUserKey();

            // Write the spaceship in the main game matrice
            _spaceship.WriteSpaceship();

            // Write the walls in the main game matrice
            _boardWall.WriteWall();

            // Move the aliens and write in the main game matrice
            MoveAndWriteAliens();

            // Write missiles in the main game matrice
            _missile.WriteMissileMoves();

            // Create a new alien shot and write them in the main game matrice
            NewAlienShootAndWriteShootMoves();

            //Print main game matric in  console
            _gameMatrice.PrintSpaceShipConsole();

            _counter++;

            // Delay of 20 milliseconds for human eyes
            Thread.Sleep(20);

            // Game continue
            return true;
        }

        /// <summary>
        /// If there is no more alien, this method create new one by reinitalise the board of alien and also shoot and missile objects
        /// </summary>
        private void NewAliens()
        {
            // No more alien are in life create a new aliens
            if (_boardAlien.NoAlienInLife())
            {
                // Create the board of Aliens controlling the aliens
                _boardAlien = new BoardAlien(gameMatriceA: _gameMatrice, boardWallA: _boardWall, scoreInfoA: _scoreInfo);

                // Create shoots
                _shoots = new Shoots(boardWall: _boardWall, boardAlien: _boardAlien, spaceShip: _spaceship, gameMatriceA: _gameMatrice, missileA: _missile, scoreInfoA: _scoreInfo);

                // Create Missle
                MissileCreation();
            }
        }

        /// <summary>
        /// Move the alien according to difficulty, write aliens in the main game matrice
        /// </summary>
        private void MoveAndWriteAliens()
        {
            // After an amount of iteration aliens move
            if (_counter % _moduloAlienMovementCounter == 0)
            {
                _boardAlien.MoveAlien();
            }

            // Write the aliens in the main game matrice
            _boardAlien.WriteAliens();
        }

        /// <summary>
        /// Move the alien shot, create new one, write them in the main game matrice
        /// </summary>
        private void NewAlienShootAndWriteShootMoves()
        {
            // After an amount of iteration an alien make a new shot
            if (_counter % _moduloShootsCounter == 0)
            {
                _shoots.NewShoot();
            }

            // Write the aliens shoots in the main game matrice
            _shoots.WriteShootMove();
        }


        /// <summary>
        /// if a player press the arrow keys move the spaceship, if the player press the spacebar the spaceship launch a missile, the player can only shot a new missile after
        /// a certain amount of time
        /// </summary>
        private void InputUserKey()
        {
            // Key pressed by the player
            ConsoleKeyInfo keyPressed;

            // player has pressed a key
            if (Console.KeyAvailable == true)
            {
                keyPressed = Console.ReadKey();

                //Move Right if the spaceship is not limited by the right border
                if (keyPressed.Key == ConsoleKey.RightArrow && _spaceship.IndexXSpaceShip < _gameMatrice.GameMatrix.GetLength(1) - _spaceship.ArrCharSpaceShip.GetLength(1))
                {
                    //Change the horizontal index  of the spaceship position
                    _spaceship.IncreaseIndexX();
                }
                //Move Left if the spaceship is not limited by the left border
                else if (keyPressed.Key == ConsoleKey.LeftArrow && _spaceship.IndexXSpaceShip > 0)
                {
                    //Change the horizontal index of the spaceship position
                    _spaceship.DecreaseIndexX();
                }
                //Launch missile if the 0,5 second have passed 
                else if (keyPressed.Key == ConsoleKey.Spacebar && _stopwatch.ElapsedMilliseconds > 500)
                {
                    // Pass the postion x and y to the spaceship, the spaceship shoot form his canon so the middle of it, because of the length of the spaceship we round
                    _missile.NewMissile();

                    // Restart the stopwatch
                    _stopwatch.Restart();
                }
            }
        }




        /// <summary>
        /// When player is in the end menu he can chose to : quit the application, reset the game (new configuration) or restart the game
        /// </summary>
        private void NewGame()
        {
            // new display of the console 
            Console.Clear();

            // According to the user decision
            switch (_endMenu.UserDecision)
            {
                // quit the application
                case "quit":
                    System.Environment.Exit(0);
                    break;
                // restart the game 
                case "restart":
                    RestartGame();
                    break;
                // reset the game (new configuration)
                case "reset":
                    ResetGame();
                    break;
            }
        }

        /// <summary>
        /// Reinitalise the different object of this gameControl and keep the highscore, the player will be back to the menu
        /// </summary>
        private void ResetGame()
        {
            // Create the menu
            _menu = new Menu();

            // Player chose the configuration of the menu easy or hard mode, sound on or off
            _menu.selectParam();

            // Create timer
            _stopwatch = new Stopwatch();

            // Create main matrice game 
            _gameMatrice = new GameMatrice();

            // Create new space ship
            _spaceship = new SpaceShip(gameMatriceA: _gameMatrice);

            // Set the life of the player, movement speed of the alien, occurence Aliens shot according to difficulty choice
            gameDifficulty();

            // Create the board of walls controlling the walls
            _boardWall = new BoardWall(gameMatriceA: _gameMatrice, arrCharSpaceShipP: _spaceship.ArrCharSpaceShip);

            // Create the board of Aliens controlling the aliens
            _boardAlien = new BoardAlien(gameMatriceA: _gameMatrice, boardWallA: _boardWall, scoreInfoA: _scoreInfo);

            // Create a soundobject and missile according to sound choice
            SoundObject();

            // Create shoots
            _shoots = new Shoots(boardWall: _boardWall, boardAlien: _boardAlien, spaceShip: _spaceship, gameMatriceA: _gameMatrice, missileA: _missile, scoreInfoA: _scoreInfo);

            //Print the main game matrice int
            _gameMatrice.SetPrintMatrix();

            // Start timer
            _stopwatch.Start();

            // Launch the game
            GameOn();
        }

        /// <summary>
        /// Reinitalise the different object of this gameControl(not the menu), keeps the highscore and the different options of the player
        /// </summary>
        private void RestartGame()
        {
            // Create timer
            _stopwatch = new Stopwatch();

            // Create main matrice game 
            _gameMatrice = new GameMatrice();

            // Create new space ship
            _spaceship = new SpaceShip(gameMatriceA: _gameMatrice);

            // Set the life of the player, movement speed of the alien, occurence Aliens shot according to difficulty choice
            gameDifficulty();

            // Create the board of walls controlling the walls
            _boardWall = new BoardWall(gameMatriceA: _gameMatrice, arrCharSpaceShipP: _spaceship.ArrCharSpaceShip);

            // Create the board of Aliens controlling the aliens
            _boardAlien = new BoardAlien(gameMatriceA: _gameMatrice, boardWallA: _boardWall, scoreInfoA: _scoreInfo);

            // Create a soundobject and missile according to sound choice
            SoundObject();

            // Create shoots
            _shoots = new Shoots(boardWall: _boardWall, boardAlien: _boardAlien, spaceShip: _spaceship, gameMatriceA: _gameMatrice, missileA: _missile, scoreInfoA: _scoreInfo);

            //Print the main game matrice int
            _gameMatrice.SetPrintMatrix();

            // Start timer
            _stopwatch.Start();

            // Launch the game
            GameOn();
        }

        /// <summary>
        /// Store value of the HighScore, if the player chose to restart the game or reset the game
        /// </summary>
        private void storeHighScore()
        {
            // the Score at the end of a game is bigger than the current highscore 
            if (_scoreInfo.Score > _currentHighscore)
            {
                // store the new highscore
                _currentHighscore = _scoreInfo.Score;
            }
        }
    }
}
