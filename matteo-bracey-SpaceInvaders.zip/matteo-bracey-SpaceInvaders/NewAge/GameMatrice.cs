﻿using System;
// ETML
// Autor: Matteo Bracey
// Date : 12.05.2022
// Description: Dimension of the matrice game (board game), each is cell is one charachter, the matrice is then print in the console
// To make the game fluid we only print the cell that have changed between each "turn" (main loop iteration in the GameControl)

namespace NewAge
{
    class GameMatrice
    {
        // According to console size and score area
        private int _gameHeight;
        private int _gameWidth;

        //Matrice of the game according to the console dimension of the console and the score area
        public char[,] GameMatrix {get; private set; }

        //Matrice of the game of the previous game turn according to the console dimension of the console and the score area
        // use to print the matrice in the console
        public char[,] GameMatrixOld { get; private set; } 

        //Size in line of the display score in the top of the console
        public int scoreDisplayHeight = 3;


        public GameMatrice()
        {
            // height of the game matrice according to score area height
            _gameHeight = Console.WindowHeight - scoreDisplayHeight;

            // width according to the console width, reduce by one for visibility purpose
            _gameWidth = Console.WindowWidth - 1;

            // Game matrice 
            GameMatrix = new char[this._gameHeight, this._gameWidth];
        }

        /// <summary>
        /// First print matrice in the console, because the next "prints" of the matrice will only be where the charachter have changed
        /// </summary>
        public void SetPrintMatrix()
        {
            // Print each cell of the matrix in the console
            for (int j = 0; j < GameMatrix.GetLength(0); j++)
                for (int i = 0; i < GameMatrix.GetLength(1); i++)
                {
                    // Add score area height 
                    Console.SetCursorPosition(i, j + scoreDisplayHeight);
                    Console.Write(GameMatrix[j, i]);
                }

            // stock the current matrice
            this.MatriceDuplication();
        }

        /// <summary>
        /// To make the game fluid we print only the cell that have been changed between the old and the new matrice 
        /// </summary>
        public void PrintSpaceShipConsole()
        {
            // Go threw each cell of the current matrice
            for (int j = 0; j < GameMatrix.GetLength(0); j++)
                for (int i = 0; i < GameMatrix.GetLength(1); i++)
                {
                    // if the cell is different in the current matrice by comparing it to the old one, we print the cell
                    if (!(GameMatrixOld[j, i] == GameMatrix[j, i]))
                    {
                        Console.SetCursorPosition(i, j + scoreDisplayHeight);
                        Console.Write(GameMatrix[j, i]);
   
                    }
                }
            // stock current matrix and clear it
            this.MatriceDuplication();
        }

        /// <summary>
        /// Stock the current matrice and clear it
        /// </summary>
        private void MatriceDuplication()
        {
            // Stock current matrice
            GameMatrixOld = GameMatrix;

            //Clear game matrice
            GameMatrix = new char[GameMatrixOld.GetLength(0), GameMatrixOld.GetLength(1)];
        }
    }
}
