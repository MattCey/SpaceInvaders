﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace spaceInvader_unit_test
{
    [TestClass]
    public class SpaceInvadersTests
    {

        private int IndexXSpaceShip;
        private char[,] ArrCharSpaceShip;
        private int[,] _arrWallLife;

       [TestMethod]
        public void IndexXSpaceCannon_WithValue5_And_6_Result_8()
        {
            // Arrange 
             IndexXSpaceShip = 5;
             ArrCharSpaceShip = new char[6, 6];
            int result = 0;

            // Act
            result = IndexXSpaceShipCannon();

            //Assert
            Assert.AreEqual(8, result);


        }

        [TestMethod]
        public void ReduceBrickLife_WithValue2_And_0_Result_0()
        {
            // Arrange
            int indexX = 2;
            int indexY = 0;

            _arrWallLife = new int[,] { { 1, 1, 1 }, { 1, 1, 1 } };

            // Act 
            ReduceBrickLife(brickXIndex: indexX, brickYIndex: indexY);

            // Assert
            Assert.AreEqual(0, _arrWallLife[indexY, indexX]);


        }

        /// <summary>
        /// Calculate and give the horizontal index of the spaceship cannon in the gamematrice
        /// </summary>
        /// <returns>horizontal index of the spaceship cannon where the missile will be launched</returns>
        public int IndexXSpaceShipCannon()
        {
            // Index of the cannon of the spaceship, addition of the index of the first chararchter of the spaceship plus the half of the length of the spaceship where the cannon is
            return IndexXSpaceShip + ArrCharSpaceShip.GetLength(1) / 2;
        }


        /// <summary>
        /// Reduce the life of a brick of the Wall, if it is stril in life
        /// </summary>
        /// <param name="brickXIndex">vertical index</param>
        /// <param name="brickYIndex">horizontal index</param>
        private void ReduceBrickLife(int brickXIndex, int brickYIndex)
        {
            // life of the brick superior to 0
            if (_arrWallLife[brickYIndex, brickXIndex] > 0)
            {
                // Reduce Life of the Brick
                _arrWallLife[brickYIndex, brickXIndex]--;
            }
        }
    }
}
